//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TStatusBar *StatusBar1;
	TMainMenu *MainMenu1;
	TMenuItem *Plik1;
	TMenuItem *Plik2;
	TMenuItem *Zapisz1;
	TMenuItem *Zapisz2;
	TMenuItem *Koniec1;
	TMenuItem *Koniec2;
	TMenuItem *dodajnowy1;
	TMenuItem *dodajnowy2;
	TListBox *ListBox1;
	TPanel *Panel1;
	void __fastcall Koniec1Click(TObject *Sender);
	void __fastcall zlap(TObject *Sender, TMouseButton Button, TShiftState Shift, int X,
          int Y);
	void __fastcall ruszaj(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall puszczaj(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall inicjuj(TObject *Sender);
	void __fastcall dodajnowy1Click(TObject *Sender);
	void __fastcall dodajnowy2Click(TObject *Sender);
	void __fastcall wybrany(TObject *Sender);
	void __fastcall poczatek(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
TList *Lista_1;
//---------------------------------------------------------------------------
#endif
