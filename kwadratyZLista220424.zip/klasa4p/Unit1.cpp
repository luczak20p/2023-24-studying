//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int startx,starty,ilosc=0,nr_aktywny;
TGraficzna *roboczy=NULL,*aktywny=NULL;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall TGraficzna::TGraficzna(TComponent* Owner)
	: TShape(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGraficzna::Paint(){
	Canvas->MoveTo(0,0);
	Canvas->LineTo(40,40);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Koniec1Click(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::zlap(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y)
{
	   if(aktywny!=NULL){
			aktywny->Brush->Color=clWhite;
	   }
	   startx=X;
	   starty=Y;
	   roboczy=(TGraficzna *) Sender;
	   roboczy->Brush->Color=clGreen;
	   aktywny=roboczy;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::ruszaj(TObject *Sender, TShiftState Shift, int X, int Y)
{
 if (roboczy!=NULL)
 {
	 roboczy->Left=roboczy->Left+X-startx;
     roboczy->Top=roboczy->Top+Y-starty;
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::puszczaj(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y)
{
  //roboczy->Brush->Color=clWhite;
  roboczy=NULL;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::inicjuj(TObject *Sender)
{
   roboczy=NULL;
   //ilosc=Form1->ComponentCount;
   StatusBar1->Panels->Items[1]->Text=IntToStr(ilosc);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::dodajnowy1Click(TObject *Sender)
{
 AnsiString linia;
 TGraficzna *nowy;
 nowy=new TGraficzna(Form1);
 Lista_1->Add(nowy);
 ilosc=Lista_1->Count;
 nowy->Parent=Panel1;
 nowy->OnMouseDown=zlap;
 nowy->OnMouseMove=ruszaj;
 nowy->OnMouseUp=puszczaj;
 linia="element "+IntToStr(ilosc);
 ListBox1->Items->Add(linia);
 inicjuj(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::dodajnowy2Click(TObject *Sender)
{
  if (aktywny!=NULL) {
	 ListBox1->Items->Delete(nr_aktywny);
	 Lista_1->Delete(nr_aktywny);
	 aktywny->Free();
	 aktywny=NULL;
	 roboczy=NULL;
	 ilosc--;
	 inicjuj(Sender);
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wybrany(TObject *Sender)
{
  int numer;
  numer=ListBox1->ItemIndex;
  nr_aktywny=numer;
  if(numer>=0){
	if(aktywny!=NULL){
		aktywny->Brush->Color=clWhite;
	}
	aktywny=(TGraficzna *) Lista_1->Items[numer];
	aktywny->Brush->Color=clGreen;
	StatusBar1->Panels->Items[3]->Text=IntToStr(numer);
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::poczatek(TObject *Sender)
{
    Lista_1=new TList();
}
//---------------------------------------------------------------------------

