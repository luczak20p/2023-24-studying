//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TStatusBar *StatusBar1;
	TMainMenu *MainMenu1;
	TMenuItem *Plik1;
	TMenuItem *Otwrz1;
	TMenuItem *N1;
	TMenuItem *N2;
	TMenuItem *Figura1;
	TMenuItem *Figura2;
	TMenuItem *Usuaktywne1;
	TMenuItem *Usuaktywne2;
	TMenuItem *Informacjeoprogramie1;
	TListBox *ListBox1;
	TPanel *Panel1;
	TShape *Shape1;
	void __fastcall N2Click(TObject *Sender);
	void __fastcall inicjuj(TObject *Sender);
	void __fastcall zlap(TObject *Sender, TMouseButton Button, TShiftState Shift, int X,
          int Y);
	void __fastcall puszczah(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall ruszaj(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall Figura2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
