//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int ilosc, startx, starty;
TShape *roboczy;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N2Click(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::inicjuj(TObject *Sender)
{
   ilosc=Form1->ComponentCount;
   ilosc=ilosc-13;
   StatusBar1->Panels->Items[1]->Text=IntToStr(ilosc);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::zlap(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y)
{
	startx = X;
	starty = Y;
    roboczy=(TShape *)Sender;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::puszczah(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y)
{
    roboczy=NULL;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ruszaj(TObject *Sender, TShiftState Shift, int X, int Y)
{
	if(roboczy!=NULL){
		roboczy->Left=roboczy->Left+X-startx;
        roboczy->Top=roboczy->Top+Y-starty;
	}

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Figura2Click(TObject *Sender)
{
	TShape *nowy;
	nowy = new TShape(Form1);
	nowy->Parent=Panel1;
	nowy->OnMouseDown->zlap;
	nowy->OnMouseMove->ruszaj;
	nowy->OnMouseUp->puszczah;
	inicjuj(Sender);
}
//---------------------------------------------------------------------------
